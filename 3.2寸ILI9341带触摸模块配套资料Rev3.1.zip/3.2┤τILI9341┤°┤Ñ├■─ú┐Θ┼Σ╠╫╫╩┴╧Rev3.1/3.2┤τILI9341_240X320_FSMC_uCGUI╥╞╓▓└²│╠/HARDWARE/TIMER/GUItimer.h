#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"
void TIM3_Init(u16 arr,u16 psc);
void TIM3_Pwm_Init(u16 arr,u16 psc);
void TIM5_PwmRemap_Init(u16 arr,u16 psc); 

#endif
